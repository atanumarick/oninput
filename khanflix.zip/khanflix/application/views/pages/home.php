<h2><?php echo $title; ?></h2>
<p>welcome to khanflix application!</p>
