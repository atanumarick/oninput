<h2><?php echo $title; ?></h2>
<p>this is ci  version 1.0</p>