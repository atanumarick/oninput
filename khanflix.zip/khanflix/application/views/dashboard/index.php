<?php  echo $title; ?>
<h1>welcome to dashbaord</h1>

<a href="<?php echo base_url();?>users/logout">logout</a>